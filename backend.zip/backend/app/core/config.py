# Core configuration settings
